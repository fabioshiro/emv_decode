package org.fx3.emv.qr;

public interface CRCCalculator {

	public String computeCRC(String data);

}
